timestep              = 0.01
random_seed           = 0

image_dir             = "images/"
plot_dir              = "plots/"

threads               = 2
framerate_limit       = int(round(1.0/timestep))

plot_sample_frequency = 0.1
flowrate_moving_avg   = 5.0
